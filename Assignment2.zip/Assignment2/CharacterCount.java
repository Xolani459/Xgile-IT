import java.util.Scanner;
import java.util.*;

public class CharacterCount
{

public static void main(String args[])
{
int count=0;
String str;
Scanner sc = new Scanner(System.in);
System.out.println("Enter the string: ");
str = sc.nextLine();

long totalstring = str.chars().filter(ch -> ch != ' ').count();

System.out.println("There are total " + totalstring + " characters in exampleString");

}
}