import java.util.Scanner;
import java.util.*;

public class ReverseString{

public static void main(String args[])
{
String input;
String temp="";

Scanner sc = new Scanner(System.in);
System.out.println("Enter String");
input = sc.nextLine();

int length= input.length();

for (int i = length -1;i >=0;i--)
{
temp =temp + input.charAt(i);
}
	System.out.println("String before reversing :" + input);
	System.out.println("Strubg after reversing: "+ temp);
}	

}