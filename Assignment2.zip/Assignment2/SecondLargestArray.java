import java.util.Arrays;

public class SecondLargestArray
{
	public static int SecLargestNum(int []a, int total)
	{
		Arrays.sort(a);
		return a[tota -2];
	}
	
	public static void main (String args[])
	{
		int a[] = {1,2,3,5,6,7,3};
		int b[] = {32,41,74,22,83,21};
		System.out.println("Second Largest: "+getSecondLargest(a,6));  
		System.out.println("Second Largest: "+getSecondLargest(b,7));  
	}
}