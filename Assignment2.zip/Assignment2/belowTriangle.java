import java.util.Scanner;

public class belowTriangle

{

    public static void main(String[] args)

    {
		int rows = 5,k = 0;
char last = 'E', alphabet = 'A';

		for (int i = rows; i >= 1; --i) 
		{
			for (int j = 1; j <= i; ++j) {
				System.out.print("# ");
		}
      System.out.println();
	
    }
	for (int x = 1; x <= rows; ++x,k = 0) 
	{
      for (int y = 1; y <= rows - 2; ++y) 
	  {
        System.out.print(" ");
      }
      while (k !=2 * x - 2)
	  {
		  System.out.print(alphabet);
		  ++k;
	  }

      System.out.println();
    }

    }
}